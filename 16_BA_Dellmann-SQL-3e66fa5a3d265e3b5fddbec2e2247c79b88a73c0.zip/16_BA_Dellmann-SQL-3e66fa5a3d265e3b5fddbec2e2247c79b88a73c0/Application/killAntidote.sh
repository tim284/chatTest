sudo docker rm -f antidote
