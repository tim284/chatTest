#!/bin/bash

sleep 10;
escript /code/connect_dcs.erl
