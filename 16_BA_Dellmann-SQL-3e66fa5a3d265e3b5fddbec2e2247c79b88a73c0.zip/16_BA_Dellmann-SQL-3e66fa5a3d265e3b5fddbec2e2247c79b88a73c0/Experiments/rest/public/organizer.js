function addEvent(event){
    source.events.push(  event);
    invalidateEvents();
}
function addEvents(events){
    $('#calendar').fullCalendar('removeEventSource', source);
    source.events = [];
    $('#calendar').fullCalendar('addEventSource', source);
    for(var i = 0; i<events.length;i++) {
        source.events.push(events[i]);
    }
        $('#calendar').fullCalendar('addEventSource', source);
        //invalidateEvents();

}

function invalidateEvents() {
    /*$('#calendar').fullCalendar('removeEventSource', source);
    $('#calendar').fullCalendar('addEventSource', source);
    $('#calendar').fullCalendar('refetchEvents' );*/
}
function serverRequest(requestUrl,value, success){
    xhr = new XMLHttpRequest();
    var url = requestUrl;
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var json = JSON.parse(xhr.responseText);
            success(json);
        }
    };
    var data = JSON.stringify(value);
    xhr.send(data);
}

function addNewParticipant() {
    consoleAdd("send AddNewParticipant Request");
    var val = document.getElementById("newParticipant").value;
    if(val=="")
        consoleAdd("Participant name cannot be empty!");
    else
    {
        serverRequest("http://localhost:3000/api/addParticipant",{name:val}, function (json) {
            consoleAdd("addNewParticipant: " + json.result);
            getUpdates();
        })
    }
    $('#newParticipant').val("");
    currentParticipant = val;
}

function editAppointment(){
    consoleAdd("Current ID for editing: " + currentID);
    var newApp = getAppointmentFromForm();
    newApp.id = currentID;
    serverRequest("http://localhost:3000/api/editAppointment", {id:currentID, app:newApp}, function (json) {
        consoleAdd("editAppointment: " + json.result);
        getUpdates()
    })
}
function removeAppointment(){
    consoleAdd("Current ID for deleting: " + currentID);
    serverRequest("http://localhost:3000/api/removeAppointment", {id: currentID}, function (json) {
        consoleAdd("removeAppointment: " + json.result);
        getUpdates();
    })
}
function addAppointment() {
    if(currentParticipant=="") {
        alert("Participant must not be empty!");
        return;
    }
    var app = getAppointmentFromForm();
    //addEvent(res);
    serverRequest("http://localhost:3000/api/addAppointment", {participant:currentParticipant,
    calendar:currentCalendar,appointment:app}, function (json) {
        consoleAdd("addAppointment: " + json.result);
        getUpdates();
        currentID = "";
    })
}
function solveAppointment() {

}
function getUpdates() { // funktioniert
    consoleAdd("update request");
    serverRequest("http://localhost:3000/api/update",{participant:currentParticipant,calendar: currentCalendar}, function (json) {
        setParticipants(json.participants);
        addEvents(json.apps);
    });
}

function consoleAdd(text) {
    $('#console').val($('#console').val() + "\n" + text);
}
