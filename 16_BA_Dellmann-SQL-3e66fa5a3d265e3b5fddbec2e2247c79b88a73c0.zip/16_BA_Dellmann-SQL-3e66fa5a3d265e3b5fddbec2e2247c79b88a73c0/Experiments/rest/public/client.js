//source field for the calendar
var source = {
    events: [],
    color: 'black',     // an option!
    textColor: 'yellow' // an option!
};
var currentParticipant = "";
var currentCalendar = "business";
var currentID = "";

var allDayChecked = false;
$(document).ready(function(){
    initialize();
    $('#calendar').fullCalendar({
        header: {
            left: "prev,next",
            center: "",
            right: 'agendaWeek'
        },
        defaultView: "agendaWeek",
        allDaySlot: true,
        minTime: "08:00:00",
        maxTime: "19:00:00",
        height: 500,
        draggable: true,
        eventSources: [
            ],
        eventClick: function(calEvent, jsEvent, view) {
            eventClick(calEvent);
        },
        dayClick: function( date, jsEvent, view) {
            dayClick(date);
        }
    });
});
function onEnterNewParticipant(event)
{
    var code = 0;
    code = event.keyCode;
    if (code==13)
        addNewParticipant();
}
function onChangeCbCalendars(e){
    var optionSelected = $("option:selected", e);
    var valueSelected = e.value;
    currentCalendar = valueSelected;
}
function onChangeCbNames(e) {
    var optionSelected = $("option:selected", e);
    var valueSelected = e.value;
    currentParticipant = valueSelected;
    getUpdates();
}
function handleCBClick(cb) {
    allDayChecked = cb.checked;
    if(allDayChecked)
        document.getElementById('iendDate').style.visibility = "hidden";
    else
        document.getElementById('iendDate').style.visibility = "visible";
}

function getAppointmentFromForm(){
    var name = document.getElementById('iname').value ;
    var x = document.getElementById("istartDate").value;
    var sDate = new Date(document.getElementById('istartDate').value );
    sDate.setHours(sDate.getHours());
    var eDate = new Date(document.getElementById('iendDate').value );
    eDate.setHours(eDate.getHours());
    var desc = $('#desc').val();
    var allday = isAllDayChecked();
    var description = document.getElementById("idesc").value;
    var priority = document.getElementById("ipriority").value;
    var res =
    {
        id: 0,
        title: name,
        start: sDate,
        end: eDate,
        allDay : allday,
        description : description,
        participants: [],
        priority: priority
    };
    return res;
}

function setEventToForm(ev){
    currentID = ev.id;
    document.getElementById("iallDay").checked = ev.allDay;
    handleCBClick(document.getElementById("iallDay"));
    var start = new Date(ev.start);
    var end;
    if(ev.end==null) {
        end = start;
        end.setMinutes(start.getMinutes()+30);
    }
    else
        end = new Date(ev.end);
    var str1 = start.getFullYear() + "-" +
        ((start.getMonth()+1).toString().length<2? "0" + (start.getMonth()+1): (start.getMonth()+1))
        + "-" +
        (start.getDate().toString().length<2? "0" + (start.getDate()): (start.getDate()))+ "T" +
        ((start.getHours()-1).toString().length<2? "0" + (start.getHours()-1): (start.getHours()-1)) + ":" +
        (start.getMinutes().toString().length<2? "0" + start.getMinutes(): start.getMinutes()) ;
    document.getElementById('istartDate').value = str1;
    var str2 = end.getFullYear() + "-" +
        ((end.getMonth()+1).toString().length<2? "0" + (end.getMonth()+1): (end.getMonth()+1))
        + "-" +
        (end.getDate().toString().length<2? "0" + (end.getDate()): (end.getDate()))+ "T" +
        ((end.getHours()-1).toString().length<2? "0" + (end.getHours()-1): (end.getHours()-1)) + ":" +
        (end.getMinutes().toString().length<2? "0" + end.getMinutes(): end.getMinutes()) ;
    document.getElementById('iendDate').value = str2;
    $('#iname').val(ev.title);
    $('#idesc').val(ev.description);
    $('#ipriority').val(ev.priority);
}

function isAllDayChecked(){
    return  allDayChecked;
}

function initialize(){
    document.getElementById('istartDate').value = "2016-12-24T10:00:00";
    document.getElementById('iendDate').value = "2016-12-24T12:00:00";
    $('#name').val("Weihnachten");
    $('#allDay').checked = false;
    document.getElementById("iedit").disabled = true;
    document.getElementById("idelete").disabled = true;
    document.getElementById("iadd").disabled = false;
}



function dayClick(date){
    currentID = "";
    var start = new Date(date);
    start.setHours(start.getHours());
    var end = new Date(date);
    end.setMinutes(end.getMinutes()+30);
    end.setHours(end.getHours());
    setEventToForm({start: start, end: end});
    document.getElementById("iedit").disabled = true;
    document.getElementById("idelete").disabled = true;
    document.getElementById("iadd").disabled = false;
}
function eventClick(ev){
    setEventToForm(ev);
    document.getElementById("iadd").disabled = true;
    document.getElementById("iedit").disabled = false;
    document.getElementById("idelete").disabled = false;
}

function setParticipants(participants){
    var tmp = currentParticipant;
    var x = document.getElementById("cbNames");
    var y = document.getElementById("iselParticipants");
    $('#cbNames').empty();
    $('#selParticipants').empty();
    y.size = participants.length;
    x.size= 1;
    for(var i = 0; i<participants.length;i++) {
        var option1 = document.createElement("option");
        option1.text = participants[i];
        var option2 = document.createElement("option");
        option2.text = participants[i];
        x.add(option1);
        y.add(option2);
    }
    document.getElementById('cbNames').value = tmp;
}
function enableInput() {
    var input = $('#appInputForm');
    var choose = $('#appChooseForm');
    choose.hide();
    input.show();
}
function enableChoose() {
    var input = $('#appInputForm');
    var choose = $('#appChooseForm');
    input.hide();
    choose.show();
}
//============================ handling for the "chooseForm"

function getAppointmentFromChooseForm(){
    var name = document.getElementById('iname').value ;
    var x = document.getElementById("istartDate").value;
    var sDate = new Date(document.getElementById('istartDate').value );
    sDate.setHours(sDate.getHours());
    var eDate = new Date(document.getElementById('iendDate').value );
    eDate.setHours(eDate.getHours());
    var desc = $('#desc').val();
    var allday = isAllDayChecked();
    var description = document.getElementById("idesc").value;
    var priority = document.getElementById("ipriority").value;
    var res =
        {
            id: 0,
            title: name,
            start: sDate,
            end: eDate,
            allDay : allday,
            description : description,
            participants: [],
            priority: priority
        };
    return res;
}

function setEventToChooseForm(ev){
    currentID = ev.id;
    /*$('#callDay').empty();
    var x = document.getElementById("callDay");
    for(var i = 0;i<ev.allDay.length;i++){
        var option1 = document.createElement("option");
        option1.text = ev.allDay[i];
        x.add(option1);
    }*/
    $('#cname').empty();
    var x = document.getElementById("cname");
    for(var i = 0;i<ev.title.length;i++){
        var option1 = document.createElement("option");
        option1.text = ev.title[i];
        x.add(option1);
    }
    $('#cdesc').empty();
    var x = document.getElementById("cdesc");
    for(var i = 0;i<ev.description.length;i++){
        var option1 = document.createElement("option");
        option1.text = ev.description[i];
        x.add(option1);
    }
    $('#cpriority').empty();
    var x = document.getElementById("cpriority");
    for(var i = 0;i<ev.priority.length;i++){
        var option1 = document.createElement("option");
        option1.text = ev.priority[i];
        x.add(option1);
    }
    $('#cstartDate').empty();
    var x = document.getElementById('cstartDate');
    var y = document.getElementById('cendDate');
    for(var i = 0;i<ev.start.length;i++) {
        var start = new Date(ev.start[i]);
        var str1 = start.getFullYear() + "-" +
            ((start.getMonth() + 1).toString().length < 2 ? "0" + (start.getMonth() + 1) : (start.getMonth() + 1))
            + "-" +
            (start.getDate().toString().length < 2 ? "0" + (start.getDate()) : (start.getDate())) + "T" +
            ((start.getHours() - 1).toString().length < 2 ? "0" + (start.getHours() - 1) : (start.getHours() - 1)) + ":" +
            (start.getMinutes().toString().length < 2 ? "0" + start.getMinutes() : start.getMinutes());
        var option1 = document.createElement("option");
        option1.text = str1;
        x.add(option1);
    }
    $('#cendDate').empty();

    for(var i = 0;i<ev.end.length;i++) {
        var end = new Date(ev.end[i]);
        var str2 = end.getFullYear() + "-" +
            ((end.getMonth()+1).toString().length<2? "0" + (end.getMonth()+1): (end.getMonth()+1))
            + "-" +
            (end.getDate().toString().length<2? "0" + (end.getDate()): (end.getDate()))+ "T" +
            ((end.getHours()-1).toString().length<2? "0" + (end.getHours()-1): (end.getHours()-1)) + ":" +
            (end.getMinutes().toString().length<2? "0" + end.getMinutes(): end.getMinutes()) ;
        var option1 = document.createElement("option");
        option1.text = str2;
        if (document.getElementById('cendDate') != null)
            y.add(option1);
    }
    for(var i = 0;i<ev.allDay.length;i++){
        var option1 = document.createElement("option");
        option1.text = ev.allDay[i];
        if(option1.text=="true")
            if (document.getElementById('cendDate') != null)
                y.add(option1);
    }
}

function test(){
    var conflict = {
        id: ["textID"],
        title: ["title1", "title2"],
        start: [new Date(),new Date().setMonth(6)],
        end: [new Date(),new Date().setMonth(8)],
        allDay: [true,false],
        description: ["desc1", "desc2"],
        priority : [3,5],
        participants: ["Ich, Du, Er"]
    }
    setEventToChooseForm(conflict);
}