var express = require('express')
var app = express()
var conf = require('./config.json');
var	antidoteClient = require('antidote_ts_client');

var antidote = antidoteClient.connect(process.env.ANTIDOTE_PORT||8087, process.env.ANTIDOTE_HOST || "localhost");

var UserSet = antidote.set("users");
UserSet.read().then(_=>console.log("Connection established to antidote with UserSet: " + _))
	.catch(err=>console.log("Connection to antidote failed", err));
var AppMap = antidote.map("appointments");

function UserApps(user,calendar) {
    return antidote.map(user + "_apps").set(calendar);
}
var ident = "server123";
var count = 0;

exports.readAllUserAppos = function(user,calendar){ //all aIds of an user,calender tuple;
    return UserApps(user,calendar).read();
}
exports.readAllAppointments = function(){ // all aId-Appointment tuples
    return AppMap.read();
}
exports.readAllParticipants = function(){ // all participants
    return UserSet.read();
}
exports.addParticipant = function(participant){
    return antidote.update(UserSet.add(participant))
}
exports.writeNewAppointment = function(participant,calendar,app){
    var id = getNewId();
    app.id = id;
    /* working version with 1. Solution for AppMap
    antidote.update(AppMap.multiValueRegister(id).set(app))
        .then(_=>{console.log("App " + app.toString() + " wrote with id " + id + " in AppMap");

        })
        .catch(err=>console.log("Failed to write app" + app.toString() + " with id " + id + " in AppMap",err));
    */
    var userApps = UserApps(participant,calendar);
    return antidote.update(
        [
            AppMap.map(id).multiValueRegister("id").set(app.id),
            AppMap.map(id).multiValueRegister("title").set(app.title),
            AppMap.map(id).multiValueRegister("start").set(app.start),
            AppMap.map(id).multiValueRegister("end").set(app.end),
            AppMap.map(id).multiValueRegister("allDay").set(app.allDay),
            AppMap.map(id).multiValueRegister("description").set(app.description),
            AppMap.map(id).set("participants").addAll(app.participants),
            AppMap.map(id).multiValueRegister("priority").set(app.priority),
            userApps.add(id)
        ]
    );
}
exports.updateAppointment = function(aId, app) {
    antidote.update(AppMap.map(aId).multiValueRegister("allDay").set(false));
    return antidote.update(
        [
            AppMap.map(aId).multiValueRegister("id").set(app.id),
            AppMap.map(aId).multiValueRegister("title").set(app.title),
            AppMap.map(aId).multiValueRegister("start").set(app.start),
            AppMap.map(aId).multiValueRegister("end").set(app.end),
            AppMap.map(aId).multiValueRegister("allDay").set(app.allDay),
            AppMap.map(aId).multiValueRegister("description").set(app.description),
            AppMap.map(aId).set("participants").addAll(app.participants),
            AppMap.map(aId).multiValueRegister("priority").set(app.priority),
        ]
    );
}
exports.deleteAppointment = function(aId){
    return antidote.update(AppMap.remove(AppMap.map(aId)));
}


function getNewId(){
    count++;
    return ident + "_" + count;
}
