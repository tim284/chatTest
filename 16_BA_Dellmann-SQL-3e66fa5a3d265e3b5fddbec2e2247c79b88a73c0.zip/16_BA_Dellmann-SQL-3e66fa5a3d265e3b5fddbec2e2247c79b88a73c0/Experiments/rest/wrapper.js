var storage = require('./storage.js');

var appDict = {};

exports.getAllAppointments = function () {

}

exports.addAppointment = function(participant,calendar,app,res){
    var result = storage.writeNewAppointment(participant,calendar,app);
    result.then(_=>{console.log("Appointment successfully saved under id: " + _.id);res.send({result:true});})
        .catch(err=>{console.log("Failed to add Appointment", err);res.send({result:false});});
}
exports.editAppointment = function(id,app,res){
    var result = storage.updateAppointment(id,app); //update appointment in antidote
    result.then(_=>{console.log("Appointment successfully edited with id: " + id + ", try to read all Appointments");
        var allApps = storage.readAllAppointments(); //read all appointments from antidote to check edited appointment
        allApps.then(_=>{
            console.log("wrapper.editAppointment.readAddAppointments successful");
            var apps = _.toJsObject();
            var edited = apps[id]; //edited is now the latest version of the appointment
            if(isConflicted(edited)){ // somewhere (but participants) has more than one value => conflict
                console.log("app with id " + id + " has conflict!");
                res.send({app: edited, conflict: true, result:true}); //send appointment to client. He is then able to "choose" the right entries...
            }
        })
            .catch(err=>console.log("wrapper.editAppointment.readAllAppointments failed", err));
        res.send({result:true, conflict: false, app:app});})
        .catch(err=>{console.log("Failed to edit Appointment", err);res.send({result:false, conflict: false, app:app});});
}
exports.removeAppointment = function(id,res){
    var result = storage.deleteAppointment(id);
    result.then(_=>{console.log("Appointment successfully removed with id: " + id);res.send({result:true});})
        .catch(err=>{console.log("Failed to remove Appointment", err);res.send({result:false});});
}
exports.addComment = function(text){

}
exports.getUpdates = function(participant, calendar, res){
    var updateObject = {participants : [],apps:[]}
    var UserApps, AllApps;

    var x = storage.readAllParticipants();
    var y = storage.readAllUserAppos(participant,calendar);
    var z = storage.readAllAppointments();

    x.then(valuea=> {
            updateObject.participants = valuea;
        y.then(valueb=> {
            UserApps = valueb;
            z.then(value=> {
                AllApps = value.toJsObject();
                if(!"length" in value.entries)
                    console.log("fehler gefunden");
                if(value.entries.length>0) {
                    updateObject.apps = compareAppsWithUserApps(AllApps, UserApps);
                }
                console.log("update successful");
                res.send(updateObject);

            }).catch(err => {console.log("GetUpdates: Participants send back to client, readAllAppointments failed",err);res.send(updateObject);})
        }).catch(err => {console.log("GetUpdates: Participants send back to client, readAllUserAppos failed",err);res.send(updateObject);})
    }).catch(err => console.log("Wrapper.getUpdates: failed to read Updates, readAllParticipants failed",err))


}
exports.addParticipant = function (participant,res) {
    var result = storage.addParticipant(participant);
    result.then(_=>{console.log("Participant succeyyfully added: " + participant);res.send({result:true});})
        .catch(err=>{console.log("Failed to add Participant", err);res.send({result:false});});
}
/* Appointment should have this form:
 var app1 = {
 id: "server_1",
 title: "Weihnachten",
 start: new Date("2016-12-24T10:30"),
 end: new Date("2016-12-24T13:30"),
 allDay : false,
 description : "Geschenke*-*",
 participants: [],
 priority: 10
 };
 */

function compareAppsWithUserApps(apps,userapps){
    var result = [];
    if(userapps=="undefined" || apps=="undefined")
        return result;
    for(var i =0;i<userapps.length;i++){
        var key = ((userapps[i]));
        if(key in apps) {
            var app = MapToJSON(apps[userapps[i]]);
            result.push(app);
        }
    }
    return result;
}

function MapToJSON(map) {
    if(Array.isArray(map))
        map = map[0];
    if(map.title.length>1)
        var x=3;
    var app = {
        id: map.id[0],
        title: map.title[0],
        start: map.start[0],
        end: map.end[0],
        allDay: map.allDay[0],
        description: map.description[0],
        participants: map.participants,
        priority : map.priority[0]
    };
    return app;
}

function isConflicted(app){
    var conflict = false;
    if(app.id.length>1)
        conflict = true;
    if(app.title.length>1)
        conflict = true;
    if(app.start.length>1)
        conflict = true;
    if(app.end.length>1)
        conflict = true;
    if(app.allDay.length>1)
        conflict = true;
    if(app.description.length>1)
        conflict = true;
    if(app.priority.length>1)
        conflict = true;
    return conflict;
}