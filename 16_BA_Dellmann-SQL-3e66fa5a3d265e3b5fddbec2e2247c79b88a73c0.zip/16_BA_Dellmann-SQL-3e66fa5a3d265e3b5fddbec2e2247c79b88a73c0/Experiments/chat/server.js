"use strict";
var express = require('express')
    ,   app = express()
    ,   server = require('http').createServer(app)
    ,   io = require('socket.io').listen(server)
    ,   conf = require('./config.json');
var	antidoteClient = require('antidote_ts_client');


// Webserver
// auf den Port x schalten

server.listen(process.env.PORT||8081);

let antidote = antidoteClient.connect(process.env.ANTIDOTE_PORT||8087, process.env.ANTIDOTE_HOST || "localhost");

let UserSet = antidote.set("users");
let AppMap = antidote.map("appointments");
function UserApps(user){
    return antidote.set('apps_' + user);
}
antidote.defaultBucket = "experiments";

var weihnachten = new Appointment("Weihnachten", new Date(2016,11,24, 17,0,0), 2, ["UserA", "UserB"]);
var krippenspiel = new Appointment("Krippenspiel", new Date(2016,11,24, 16,0,0),2, ["UserB", "UserC"]);

antidote.update(
    UserSet.addAll(["UserA","UserB","UserC"])
)
antidote.update([
    AppMap.register("1").set(weihnachten),
    AppMap.register("2").set(krippenspiel)
])


antidote.update([
  UserApps("UserA").add(1),
    UserApps("UserA").add(2),
    UserApps("UserB").add(2),
    UserApps("UserB").add(3)
])
ReadSet(UserSet);
ReadMap(AppMap);
ReadSet(UserApps("Tim"));
ReadSet(UserApps("Franzi"));
// Portnummer in die Konsole schreiben
console.log('Der Server l�uft nun unter http://127.0.0.1:' + conf.port + '/');

function Appointment(title,date,duration,participants){
    this.Participants = participants;
    this.Date = date;
    this.Duration = duration;
    this.Title = title;
    console.log("----Appointment <" + this.Title + "> erstellt. " + this.Date.toString() + ", " + this.Duration + ", [" + this.Participants +"]");
}

    app.configure(function(){
    // statische Dateien ausliefern
    app.use(express.static(__dirname + '/public'));
});

function ReadSet(val){
    return val.read().then(function(users) {
        console.log(users);
    }).catch(function(err) {
        console.log(err);
    });
}
function ReadMap(val){
    return val.read().then(function(users) {
        var obj = users.toJsObject();
        console.log(obj);
        //obj.forEach(function(name){
        //    console.log(name)
        //})
    }).catch(function(err) {
        console.log(err);
    });
}
// wenn der Pfad / aufgerufen wird
app.get('/', function (req, res) {
    // so wird die Datei index.html ausgegeben
    res.sendfile(__dirname + '/public/index.html');
});


// Websocket
io.sockets.on('connection', function (socket) {
    // der Client ist verbunden
    socket.emit('chat', new Nachricht(new Date(), "", "Du bist verbunden! Gib mir dein Geld!"));
    fileManager.ReadFile("./chatlog.txt", socket);
    // wenn ein Benutzer einen Text senden
    socket.on('chat', function (data) {
        // so wird dieser Text an alle anderen Benutzer gesendet
        if(data.text=="") return;
        if(data.text=="chatlog clear"){
            fileManager.ClearFile("./chatlog.txt");
            //io.sockets.emit('chat', new Nachricht(new Date(),"SERVER","Bisheriger Chatverlauf vom Admin gelöscht"));
            io.sockets.emit('alert', "Bisheriger Chatverlauf vom Admin gelöscht\nSeite wird neu geladen!");
            return;
        }
        if(data.text=="antidote"){
            let messages =  userSet.read();
            messages.then(function(result) {
                io.sockets.emit('antidote', result);
            }, function(err) {
                console.log(err);
            });

        }
        if(data.text=="count"){
            let c = counter.read();
            c.then(function(result){
                io.sockets.emit('count', result);
            }, function(err){
                console.log(err);
            });
        }
        fileManager.AddLine("./chatlog.txt", (new Date()).toString() + "," + data.name + "," + data.text + "|");
        count++;
        io.sockets.emit('chat', new Nachricht(new Date(),data.name,data.text));
        antidote.update(userSet.add(data.text))
            .then(_ => console.log(data.text + " wurde in antidote geschrieben"))

        .catch(err => console.log("Fehler", err));
        antidote.update(counter.increment(1))
            .then(_ => console.log("counter wurde erhöht"))
        .catch(err => console.log("Fehler", err));
    });
});
function Nachricht(zeit, name,text){
    this.zeit = zeit;
    this.name = name;
    this.text = text;
}

